import os
from pathlib import Path
os.environ["MCP_SECRETARY_MODE"] = "live-google"
os.environ["MCP_SECRETARY_LIVE_GOOGLE_PROVIDER_FILE"] = str(Path(__file__).parent / "provider_google_aprovado.py")
from donna_mcp.server import main
if __name__ == "__main__":
    main()
