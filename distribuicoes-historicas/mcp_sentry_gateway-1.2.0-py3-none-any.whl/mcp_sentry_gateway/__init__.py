"""MCP Sentry local gateway and integrity controls."""

__version__ = "1.2.0"
